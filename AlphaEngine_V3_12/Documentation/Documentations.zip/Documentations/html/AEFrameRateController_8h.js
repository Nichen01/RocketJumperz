var AEFrameRateController_8h =
[
    [ "AEFrameRateControllerEnd", "AEFrameRateController_8h.html#ab1ff1b266714fd19df48ebc3d02c6a1b", null ],
    [ "AEFrameRateControllerGetFrameCount", "AEFrameRateController_8h.html#a631b80c9f822467e156df54836b4fd3f", null ],
    [ "AEFrameRateControllerGetFrameRate", "AEFrameRateController_8h.html#aae22775a87c8ece9f8e8d2620a1cefcd", null ],
    [ "AEFrameRateControllerGetFrameTime", "AEFrameRateController_8h.html#a7fade1ddc310496915379af1e46f06d9", null ],
    [ "AEFrameRateControllerInit", "AEFrameRateController_8h.html#af9cafe94b4ef9ce1b6c831f88b5cb6cf", null ],
    [ "AEFrameRateControllerReset", "AEFrameRateController_8h.html#ae93ae6963a13d5034671fdcd6fa306db", null ],
    [ "AEFrameRateControllerStart", "AEFrameRateController_8h.html#a81b66144784075dcb2683a43c8dccbdd", null ]
];