var structAEGfxVertexList =
[
    [ "mpVtxBuffer", "structAEGfxVertexList.html#a32aed6689fd4ffe0f45412265330b257", null ],
    [ "vtxNum", "structAEGfxVertexList.html#af0ce27a2582b074d87cb1a7771042d2b", null ]
];