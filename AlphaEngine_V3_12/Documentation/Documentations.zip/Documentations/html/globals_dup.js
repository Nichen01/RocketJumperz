var globals_dup =
[
    [ "a", "globals.html", null ],
    [ "e", "globals_e.html", null ],
    [ "f", "globals_f.html", null ],
    [ "h", "globals_h.html", null ],
    [ "n", "globals_n.html", null ],
    [ "p", "globals_p.html", null ],
    [ "s", "globals_s.html", null ],
    [ "t", "globals_t.html", null ],
    [ "u", "globals_u.html", null ]
];